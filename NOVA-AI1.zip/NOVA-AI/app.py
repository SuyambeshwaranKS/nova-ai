"""
NOVA AI - Flask Backend
Powered by Google Gemini 2.5 Flash
"""

import os
import json
import time
from flask import Flask, request, jsonify, render_template
from dotenv import load_dotenv
import google.generativeai as genai

# Load environment variables
load_dotenv()

app = Flask(__name__)

# Configure Gemini API
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
if GEMINI_API_KEY:
    genai.configure(api_key=GEMINI_API_KEY)

# Model configuration
GENERATION_CONFIG = {
    "temperature": 0.9,
    "top_p": 1,
    "top_k": 1,
    "max_output_tokens": 8192,
}

SAFETY_SETTINGS = [
    {"category": "HARM_CATEGORY_HARASSMENT",       "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
    {"category": "HARM_CATEGORY_HATE_SPEECH",       "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
    {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
    {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
]

SYSTEM_INSTRUCTION = """You are NOVA AI, an advanced, helpful, and friendly AI assistant.
You provide accurate, thoughtful, and well-structured responses.
When answering:
- Use markdown formatting for better readability
- Use code blocks with language specification for code snippets
- Be concise yet comprehensive
- Be friendly and professional
- If you don't know something, say so honestly"""


def get_gemini_model():
    """Initialize and return the Gemini model."""
    return genai.GenerativeModel(
        model_name="gemini-2.5-flash",
        generation_config=GENERATION_CONFIG,
        safety_settings=SAFETY_SETTINGS,
        system_instruction=SYSTEM_INSTRUCTION,
    )


# In-memory conversation history per session (keyed by session_id)
conversation_histories = {}


@app.route("/")
def index():
    """Serve the main chat interface."""
    return render_template("index.html")


@app.route("/api/chat", methods=["POST"])
def chat():
    """Handle chat messages and return AI responses."""
    try:
        data = request.get_json()
        if not data or "message" not in data:
            return jsonify({"error": "No message provided"}), 400

        user_message = data.get("message", "").strip()
        session_id = data.get("session_id", "default")

        if not user_message:
            return jsonify({"error": "Empty message"}), 400

        if not GEMINI_API_KEY:
            return jsonify({"error": "API key not configured. Please set GEMINI_API_KEY in your .env file."}), 500

        # Get or initialize conversation history
        if session_id not in conversation_histories:
            conversation_histories[session_id] = []

        history = conversation_histories[session_id]

        # Start chat session with existing history
        model = get_gemini_model()
        chat_session = model.start_chat(history=history)

        # Send message and get response
        response = chat_session.send_message(user_message)
        assistant_message = response.text

        # Update conversation history
        conversation_histories[session_id] = chat_session.history

        return jsonify({
            "response": assistant_message,
            "session_id": session_id,
            "timestamp": int(time.time()),
        })

    except Exception as e:
        error_msg = str(e)
        if "API_KEY_INVALID" in error_msg or "API key" in error_msg:
            return jsonify({"error": "Invalid API key. Please check your GEMINI_API_KEY."}), 401
        if "quota" in error_msg.lower():
            return jsonify({"error": "API quota exceeded. Please try again later."}), 429
        return jsonify({"error": f"AI service error: {error_msg}"}), 500


@app.route("/api/clear", methods=["POST"])
def clear_history():
    """Clear conversation history for a session."""
    try:
        data = request.get_json() or {}
        session_id = data.get("session_id", "default")
        if session_id in conversation_histories:
            del conversation_histories[session_id]
        return jsonify({"success": True, "message": "Chat history cleared"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/health", methods=["GET"])
def health_check():
    """Health check endpoint."""
    return jsonify({
        "status": "healthy",
        "api_configured": bool(GEMINI_API_KEY),
        "model": "gemini-2.5-flash",
        "version": "1.0.0",
    })


if __name__ == "__main__":
    port = int(os.getenv("PORT", 5000))
    debug = os.getenv("FLASK_DEBUG", "false").lower() == "true"
    print(f"\n🚀 NOVA AI is running at http://localhost:{port}")
    print(f"   API Key configured: {'✅ Yes' if GEMINI_API_KEY else '❌ No — set GEMINI_API_KEY in .env'}\n")
    app.run(host="0.0.0.0", port=port, debug=debug)
