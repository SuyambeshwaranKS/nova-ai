/* ═══════════════════════════════════════════════════════
   NOVA AI — script.js
   Chat logic · Voice · Markdown · Theme · Export
═══════════════════════════════════════════════════════ */

"use strict";

// ── State ──────────────────────────────────────────────
const state = {
  sessionId: generateSessionId(),
  isProcessing: false,
  isRecording: false,
  recognition: null,
  currentTheme: localStorage.getItem("nova-theme") || "dark",
  chatLog: [], // [{role, content, timestamp}]
  chatSessions: JSON.parse(localStorage.getItem("nova-sessions") || "[]"),
  currentSessionName: null,
};

// ── DOM refs ───────────────────────────────────────────
const $ = (id) => document.getElementById(id);
const dom = {
  sidebar:        $("sidebar"),
  sidebarToggle:  $("sidebarToggle"),
  sidebarClose:   $("sidebarClose"),
  sidebarOverlay: $("sidebarOverlay"),
  chatHistory:    $("chatHistory"),
  newChatBtn:     $("newChatBtn"),
  chatContainer:  $("chatContainer"),
  welcomeScreen:  $("welcomeScreen"),
  messagesWrapper:$("messagesWrapper"),
  messageInput:   $("messageInput"),
  sendBtn:        $("sendBtn"),
  voiceBtn:       $("voiceBtn"),
  themeToggle:    $("themeToggle"),
  themeIcon:      $("themeIcon"),
  exportBtn:      $("exportBtn"),
  clearAllBtn:    $("clearAllBtn"),
  toast:          $("toast"),
  toastMessage:   $("toastMessage"),
};

// ── Init ───────────────────────────────────────────────
function init() {
  applyTheme(state.currentTheme, false);
  setupMarked();
  setupEventListeners();
  renderChatHistory();
  setupVoiceInput();
  autoResizeTextarea();
}

// ── Marked / Highlight.js setup ────────────────────────
function setupMarked() {
  const renderer = new marked.Renderer();

  // Custom code block with copy button + language label
  renderer.code = function (code, language) {
    const lang = (language || "plaintext").toLowerCase();
    const highlighted = hljs.getLanguage(lang)
      ? hljs.highlight(code, { language: lang }).value
      : hljs.highlightAuto(code).value;

    return `
      <div class="code-block-wrapper">
        <div class="code-block-header">
          <span>${lang}</span>
          <button class="copy-code-btn" onclick="copyCode(this)">
            <i class="fa-regular fa-copy"></i> Copy
          </button>
        </div>
        <pre><code class="hljs language-${lang}">${highlighted}</code></pre>
      </div>`;
  };

  marked.setOptions({ renderer, breaks: true, gfm: true });
}

// ── Event Listeners ────────────────────────────────────
function setupEventListeners() {
  // Send button
  dom.sendBtn.addEventListener("click", handleSend);

  // Textarea
  dom.messageInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  });
  dom.messageInput.addEventListener("input", () => {
    autoResizeTextarea();
    dom.sendBtn.disabled = !dom.messageInput.value.trim();
  });

  // Sidebar toggle
  dom.sidebarToggle.addEventListener("click", () => toggleSidebar(true));
  dom.sidebarClose.addEventListener("click",  () => toggleSidebar(false));
  dom.sidebarOverlay.addEventListener("click",() => toggleSidebar(false));

  // New chat
  dom.newChatBtn.addEventListener("click", newChat);

  // Theme
  dom.themeToggle.addEventListener("click", () => {
    const next = state.currentTheme === "dark" ? "light" : "dark";
    applyTheme(next, true);
  });

  // Export
  dom.exportBtn.addEventListener("click", exportChat);

  // Clear history
  dom.clearAllBtn.addEventListener("click", clearAllHistory);

  // Suggestion cards
  document.querySelectorAll(".suggestion-card").forEach((card) => {
    card.addEventListener("click", () => {
      const prompt = card.dataset.prompt;
      dom.messageInput.value = prompt;
      dom.sendBtn.disabled = false;
      handleSend();
    });
  });
}

// ── Send Message ───────────────────────────────────────
async function handleSend() {
  const text = dom.messageInput.value.trim();
  if (!text || state.isProcessing) return;

  // Hide welcome, show chat area
  hideWelcome();

  // Append user bubble
  appendMessage("user", text);
  state.chatLog.push({ role: "user", content: text, timestamp: Date.now() });

  // Clear input
  dom.messageInput.value = "";
  dom.sendBtn.disabled = true;
  autoResizeTextarea();

  // Show typing
  const typingEl = showTypingIndicator();
  state.isProcessing = true;

  try {
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: text, session_id: state.sessionId }),
    });

    const data = await res.json();

    typingEl.remove();

    if (!res.ok || data.error) {
      appendMessage("ai", `**Error:** ${data.error || "Something went wrong. Please try again."}`, true);
    } else {
      appendMessage("ai", data.response);
      state.chatLog.push({ role: "ai", content: data.response, timestamp: Date.now() });
      saveSession(text);
    }
  } catch (err) {
    typingEl.remove();
    appendMessage("ai", `**Network error:** Could not reach the server. Make sure the Flask server is running.`, true);
    console.error("Chat error:", err);
  } finally {
    state.isProcessing = false;
    scrollToBottom();
  }
}

// ── Append Message ─────────────────────────────────────
function appendMessage(role, content, isError = false) {
  const group = document.createElement("div");
  group.className = "message-group";

  const message = document.createElement("div");
  message.className = `message ${role}`;

  // Avatar
  const avatar = document.createElement("div");
  avatar.className = `avatar ${role}`;
  if (role === "user") {
    avatar.textContent = "U";
  } else {
    avatar.innerHTML = `
      <svg viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="18" cy="18" r="17" stroke="url(#ag)" stroke-width="2"/>
        <path d="M10 18 L18 10 L26 18 L18 26 Z" fill="url(#ag)" opacity="0.85"/>
        <circle cx="18" cy="18" r="4" fill="white"/>
        <defs>
          <linearGradient id="ag" x1="0" y1="0" x2="36" y2="36">
            <stop offset="0%" stop-color="#7c3aed"/>
            <stop offset="100%" stop-color="#06b6d4"/>
          </linearGradient>
        </defs>
      </svg>`;
  }

  // Bubble
  const bubbleWrapper = document.createElement("div");
  bubbleWrapper.className = "bubble-wrapper";

  const bubble = document.createElement("div");
  bubble.className = `bubble ${role}`;

  if (role === "ai") {
    bubble.innerHTML = marked.parse(content);
    if (isError) bubble.style.borderColor = "rgba(239,68,68,0.4)";
  } else {
    bubble.textContent = content;
  }

  bubbleWrapper.appendChild(bubble);

  // Action buttons (for AI messages)
  if (role === "ai") {
    const actions = document.createElement("div");
    actions.className = "message-actions";
    actions.innerHTML = `
      <button class="msg-action-btn" onclick="copyBubble(this)" title="Copy response">
        <i class="fa-regular fa-copy"></i> Copy
      </button>`;
    bubbleWrapper.appendChild(actions);
  }

  message.appendChild(avatar);
  message.appendChild(bubbleWrapper);
  group.appendChild(message);
  dom.messagesWrapper.appendChild(group);

  scrollToBottom();
}

// ── Typing Indicator ───────────────────────────────────
function showTypingIndicator() {
  const group = document.createElement("div");
  group.className = "message-group";
  group.id = "typingGroup";

  const message = document.createElement("div");
  message.className = "message ai";

  const avatar = document.createElement("div");
  avatar.className = "avatar ai";
  avatar.innerHTML = `
    <svg viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="18" cy="18" r="17" stroke="url(#tg)" stroke-width="2"/>
      <path d="M10 18 L18 10 L26 18 L18 26 Z" fill="url(#tg)" opacity="0.85"/>
      <circle cx="18" cy="18" r="4" fill="white"/>
      <defs>
        <linearGradient id="tg" x1="0" y1="0" x2="36" y2="36">
          <stop offset="0%" stop-color="#7c3aed"/>
          <stop offset="100%" stop-color="#06b6d4"/>
        </linearGradient>
      </defs>
    </svg>`;

  const indicator = document.createElement("div");
  indicator.className = "typing-indicator";
  indicator.innerHTML = `
    <div class="typing-dot"></div>
    <div class="typing-dot"></div>
    <div class="typing-dot"></div>`;

  message.appendChild(avatar);
  message.appendChild(indicator);
  group.appendChild(message);
  dom.messagesWrapper.appendChild(group);

  scrollToBottom();
  return group;
}

// ── Voice Input ────────────────────────────────────────
function setupVoiceInput() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

  if (!SpeechRecognition) {
    dom.voiceBtn.title = "Voice input not supported in this browser";
    dom.voiceBtn.style.opacity = "0.4";
    dom.voiceBtn.style.cursor = "not-allowed";
    return;
  }

  const recognition = new SpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = true;
  recognition.lang = "en-US";
  state.recognition = recognition;

  recognition.onresult = (e) => {
    const transcript = Array.from(e.results)
      .map((r) => r[0].transcript)
      .join("");
    dom.messageInput.value = transcript;
    dom.sendBtn.disabled = !transcript.trim();
    autoResizeTextarea();
  };

  recognition.onend = () => {
    state.isRecording = false;
    dom.voiceBtn.classList.remove("recording");
    dom.voiceBtn.innerHTML = `<i class="fa-solid fa-microphone"></i>`;
  };

  recognition.onerror = (e) => {
    state.isRecording = false;
    dom.voiceBtn.classList.remove("recording");
    dom.voiceBtn.innerHTML = `<i class="fa-solid fa-microphone"></i>`;
    if (e.error !== "aborted") showToast("Mic error: " + e.error, "error");
  };

  dom.voiceBtn.addEventListener("click", () => {
    if (state.isRecording) {
      recognition.stop();
    } else {
      recognition.start();
      state.isRecording = true;
      dom.voiceBtn.classList.add("recording");
      dom.voiceBtn.innerHTML = `<i class="fa-solid fa-stop"></i>`;
    }
  });
}

// ── Theme ──────────────────────────────────────────────
function applyTheme(theme, animate = true) {
  state.currentTheme = theme;
  document.documentElement.setAttribute("data-theme", theme);
  localStorage.setItem("nova-theme", theme);

  const icon = dom.themeIcon;
  if (theme === "dark") {
    icon.className = "fa-solid fa-moon";
  } else {
    icon.className = "fa-solid fa-sun";
  }

  // Swap highlight.js theme
  const hlTheme = document.getElementById("hljs-theme");
  hlTheme.href = theme === "dark"
    ? "https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/github-dark.min.css"
    : "https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/github.min.css";
}

// ── Sidebar ────────────────────────────────────────────
function toggleSidebar(open) {
  dom.sidebar.classList.toggle("open", open);
  dom.sidebarOverlay.classList.toggle("show", open);
}

// ── New Chat ───────────────────────────────────────────
function newChat() {
  if (state.chatLog.length > 0) saveSession(state.chatLog[0]?.content || "Chat");

  state.sessionId = generateSessionId();
  state.chatLog = [];
  state.currentSessionName = null;

  dom.messagesWrapper.innerHTML = "";
  dom.welcomeScreen.style.display = "";
  dom.messageInput.value = "";
  dom.sendBtn.disabled = true;

  fetch("/api/clear", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ session_id: state.sessionId }),
  }).catch(() => {});

  toggleSidebar(false);
}

// ── Hide Welcome ───────────────────────────────────────
function hideWelcome() {
  if (dom.welcomeScreen.style.display !== "none") {
    dom.welcomeScreen.style.display = "none";
  }
}

// ── Session management ─────────────────────────────────
function saveSession(firstMessage) {
  if (state.currentSessionName) return; // Already saved
  const name = firstMessage.substring(0, 40) + (firstMessage.length > 40 ? "…" : "");
  state.currentSessionName = name;

  const session = {
    id: state.sessionId,
    name,
    timestamp: Date.now(),
    log: [...state.chatLog],
  };

  // Prepend, keep max 30 sessions
  state.chatSessions = [session, ...state.chatSessions.filter(s => s.id !== state.sessionId)].slice(0, 30);
  localStorage.setItem("nova-sessions", JSON.stringify(state.chatSessions));
  renderChatHistory();
}

function renderChatHistory() {
  if (state.chatSessions.length === 0) {
    dom.chatHistory.innerHTML = `
      <div class="empty-history">
        <i class="fa-regular fa-comment-dots"></i>
        <p>No chats yet. Start a conversation!</p>
      </div>`;
    return;
  }

  dom.chatHistory.innerHTML = state.chatSessions.map((s, i) => `
    <div class="history-item ${s.id === state.sessionId ? "active" : ""}" data-index="${i}">
      <i class="fa-regular fa-message"></i>
      <span class="history-item-text">${escapeHtml(s.name)}</span>
    </div>`).join("");

  dom.chatHistory.querySelectorAll(".history-item").forEach((el) => {
    el.addEventListener("click", () => {
      const idx = parseInt(el.dataset.index);
      loadSession(state.chatSessions[idx]);
      toggleSidebar(false);
    });
  });
}

function loadSession(session) {
  state.sessionId = session.id;
  state.chatLog = [...session.log];
  state.currentSessionName = session.name;

  dom.messagesWrapper.innerHTML = "";
  hideWelcome();

  session.log.forEach((entry) => appendMessage(entry.role, entry.content));
  renderChatHistory();
}

// ── Export Chat ────────────────────────────────────────
function exportChat() {
  if (state.chatLog.length === 0) {
    showToast("No messages to export", "info");
    return;
  }

  const lines = [`NOVA AI — Chat Export\n${"═".repeat(40)}\n`];
  state.chatLog.forEach((entry) => {
    const role = entry.role === "user" ? "YOU" : "NOVA";
    const time = new Date(entry.timestamp).toLocaleString();
    lines.push(`[${time}] ${role}:\n${entry.content}\n`);
  });

  const blob = new Blob([lines.join("\n")], { type: "text/plain" });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement("a");
  a.href = url;
  a.download = `nova-chat-${new Date().toISOString().slice(0,10)}.txt`;
  a.click();
  URL.revokeObjectURL(url);
  showToast("Chat exported!");
}

// ── Clear All History ──────────────────────────────────
function clearAllHistory() {
  if (!confirm("Clear all chat history? This cannot be undone.")) return;
  state.chatSessions = [];
  localStorage.removeItem("nova-sessions");
  renderChatHistory();
  newChat();
  showToast("History cleared");
}

// ── Copy helpers ───────────────────────────────────────
function copyBubble(btn) {
  const bubble = btn.closest(".bubble-wrapper").querySelector(".bubble");
  const text = bubble.innerText;
  navigator.clipboard.writeText(text).then(() => showToast("Response copied!"));
}

function copyCode(btn) {
  const wrapper = btn.closest(".code-block-wrapper");
  const code = wrapper.querySelector("code").innerText;
  navigator.clipboard.writeText(code).then(() => {
    btn.innerHTML = `<i class="fa-solid fa-check"></i> Copied!`;
    setTimeout(() => { btn.innerHTML = `<i class="fa-regular fa-copy"></i> Copy`; }, 1800);
  });
}

// ── Toast ──────────────────────────────────────────────
let toastTimer;
function showToast(message) {
  dom.toastMessage.textContent = message;
  dom.toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => dom.toast.classList.remove("show"), 2200);
}

// ── Helpers ────────────────────────────────────────────
function scrollToBottom() {
  requestAnimationFrame(() => {
    dom.chatContainer.scrollTo({ top: dom.chatContainer.scrollHeight, behavior: "smooth" });
  });
}

function autoResizeTextarea() {
  const ta = dom.messageInput;
  ta.style.height = "auto";
  ta.style.height = Math.min(ta.scrollHeight, 200) + "px";
}

function generateSessionId() {
  return "sess_" + Math.random().toString(36).slice(2) + Date.now().toString(36);
}

function escapeHtml(str) {
  return str.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}

// ── Boot ───────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", init);
