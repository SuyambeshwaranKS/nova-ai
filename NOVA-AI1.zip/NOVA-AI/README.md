# 🚀 NOVA AI — Intelligent Chatbot

> A production-quality AI chatbot powered by **Google Gemini 2.5 Flash**, built with Flask + modern glassmorphism UI.

---

## ✨ Features

| Feature | Details |
|---|---|
| 🤖 AI Engine | Google Gemini 2.5 Flash |
| 🎨 UI | Glassmorphism · ChatGPT-style |
| 🌙 Theme | Dark / Light mode toggle |
| 📱 Responsive | Mobile + Desktop |
| 🗂️ Sidebar | Chat history with session restore |
| 🎤 Voice Input | Web Speech API |
| 📋 Copy | Copy response or code blocks |
| 📝 Markdown | Full markdown + syntax highlighting |
| 💾 Export | Download chat as `.txt` |
| ⚡ Streaming | Auto-scroll, typing indicator |

---

## 📁 Project Structure

```
NOVA-AI/
├── app.py                  # Flask backend
├── requirements.txt        # Python dependencies
├── .env                    # API keys (never commit!)
├── templates/
│   └── index.html          # Main HTML template
├── static/
│   ├── css/
│   │   └── style.css       # All styles
│   ├── js/
│   │   └── script.js       # Frontend logic
│   └── images/             # (optional assets)
└── README.md
```

---

## 🔧 Installation

### Prerequisites
- Python 3.9+
- A Google Gemini API key — get one free at [aistudio.google.com](https://aistudio.google.com/app/apikey)

### Step-by-step

**1. Clone / Download the project**
```bash
cd NOVA-AI
```

**2. Create a virtual environment**
```bash
python -m venv venv

# Activate:
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate
```

**3. Install dependencies**
```bash
pip install -r requirements.txt
```

**4. Configure your API key**

Open `.env` and replace the placeholder:
```env
GEMINI_API_KEY=your_actual_api_key_here
```

**5. Run the application**
```bash
python app.py
```

**6. Open in browser**
```
http://localhost:5000
```

---

## 🌐 API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| GET | `/` | Serve chat UI |
| POST | `/api/chat` | Send message, get AI response |
| POST | `/api/clear` | Clear session history |
| GET | `/api/health` | Health check |

### Example request
```bash
curl -X POST http://localhost:5000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello NOVA!", "session_id": "test123"}'
```

---

## 🔑 Environment Variables

| Variable | Default | Description |
|---|---|---|
| `GEMINI_API_KEY` | _(required)_ | Your Gemini API key |
| `FLASK_DEBUG` | `false` | Enable Flask debug mode |
| `PORT` | `5000` | Server port |

---

## 🎓 Tech Stack

- **Backend:** Python 3, Flask, Google Generative AI SDK
- **Frontend:** HTML5, CSS3 (custom properties, glassmorphism), Vanilla JS
- **AI Model:** `gemini-2.5-flash`
- **Libraries:** marked.js (markdown), highlight.js (syntax), Font Awesome (icons)

---

## 🛡️ Security Notes

- Never commit your `.env` file
- Add `.env` to `.gitignore`
- Use environment variables in production (not `.env` files)

---

## 📄 License

MIT — free to use for academic and personal projects.

---

*Built with ❤️ as a BCA Cloud Computing project — NOVA AI*
